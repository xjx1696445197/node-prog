<template>
    <div class="page">
        <div class="HEADER_WALLET">
            <p class="HEADER_TITLE_WALLET">投票</p>
        </div>
        <div class="back">

        </div>
        <p>功能开发中，敬请期待！</p>
    </div>
</template>

<script>
    export default {
        name: "Vote"
    }
</script>

<style scoped>
    .back{
        width: 1.8rem;
        height:1.8rem;
        margin:auto;
        margin-top:3.4rem;
        background: url("../static/images/newWallet/csbackgroud.png") no-repeat center center / cover;
    }
    .page>p{
        margin-top:.4rem;
        text-align:center;
        color:#070707;
    }
</style>
