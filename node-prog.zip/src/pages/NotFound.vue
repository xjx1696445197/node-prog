<template>
    <div>
        <div>404</div>
        <router-link tag="a" to="/a"></router-link>
    </div>

</template>

<script>
    export default {
        name: "NotFound",
    }
</script>

<style scoped>

</style>
